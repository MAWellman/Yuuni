from flask import Flask, render_template, g, request
import sqlite3

app = Flask(__name__)

g_user = None

def getDB():
    g.db = sqlite3.connect('database.db')
    g.db.row_factory = sqlite3.Row
    g.db.execute('CREATE TABLE IF NOT EXISTS users(user TEXT, password TEXT)')
    g.db.execute('CREATE TABLE IF NOT EXISTS posts(user TEXT, major TEXT, reqmajor TEXT, projtype TEXT)')
    return g.db

@app.teardown_appcontext
def closeDB(exception):
    db = g.pop('db', None)
    if db is not None:
        db.close()
    g_user = None

@app.route('/', methods=('GET', 'POST'))
def enter():
    db = getDB()
    posts = db.execute('SELECT * FROM posts').fetchall()
    size = len(posts)
    return render_template('Home.html', posts=posts, size=size)

@app.route('/about', methods=('GET', 'POST'))
def about():
    return render_template('About.html')

@app.route('/post', methods=('GET', 'POST'))
def post():
    db = getDB()
    if request.method == 'POST':
        db.execute('INSERT INTO posts(user, major, reqmajor, projtype) VALUES (?, ?, ?, ?)', (g_user, request.form['your major'], request.form['reqmajor'], request.form['project type']))
        db.commit()
        db = getDB()
        posts = db.execute('SELECT * FROM posts').fetchall()
        size = len(posts)
        return render_template('Home.html', posts=posts, size=size)
    return render_template('Post.html')

@app.route('/setup', methods=('GET', 'POST'))
def register():
    username_taken = False
    db = getDB()
    if request.method == 'POST':
        users = db.execute('SELECT * FROM users').fetchall()
        for user in users:
            if user['user'] == request.form['user']:
                username_taken = True
        if not username_taken:
            db.execute('INSERT INTO users(user, password) VALUES (?, ?)', (request.form['user'], request.form['password']))
            db.commit()
            g_user = user
            db = getDB()
            posts = db.execute('SELECT * FROM posts').fetchall()
            size = len(posts)
            return render_template('Home.html', posts=posts, size=size)
    users = db.execute('SELECT * FROM users').fetchall()
    return render_template('AccountCreation.html', users=users, username_taken=username_taken)

@app.route('/login', methods=('GET', 'POST'))
def login():
    incorrect_username = True
    incorrect_password = True
    info_entered = False
    db = getDB()
    if request.method == 'POST':
        info_entered = True
        users = db.execute('SELECT * FROM users').fetchall()
        for user in users:
            if user['user'] == request.form['user']:
                incorrect_username = False
                if user['password'] == request.form['password']:
                    incorrect_password = False
            else:
                incorrect_password = False
        if not incorrect_username and not incorrect_password:
            g_user = user['user']
            db = getDB()
            posts = db.execute('SELECT * FROM posts').fetchall()
            size = len(posts)
            return render_template('Home.html', posts=posts, size=size)
    users = db.execute('SELECT * FROM users').fetchall()
    return render_template('SignIn.html', incorrect_username=incorrect_username, incorrect_password=incorrect_password, info_entered=info_entered)

if __name__ == '__main__':
    app.run()